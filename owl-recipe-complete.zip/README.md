# OWL Recipe

OWL Recipeは、ChatGPT Plusで作成・相談したレシピJSONを貼り付け、写真と一緒に保存・検索・閲覧する個人用レシピアプリです。

OpenAI APIは使用しません。ChatGPTとの連携は手動です。

```text
アプリでプロンプトをコピー
→ 普段使っているChatGPT Plusへ貼り付け
→ ChatGPTが保存用JSONを出力
→ アプリへJSONを貼り付け
→ Google Sheets / Google Driveへ保存
```

## 構成

- フロントエンド: 静的HTML/CSS/JavaScript
- 公開先: GitHub Pages
- バックエンド: Google Apps Script Web App
- レシピ保存: Google Sheets
- 写真保存: Google Drive
- OpenAI API: 使用しない

## 実装済み機能

- ChatGPT保存用JSON Schemaの定義
- GPT用固定プロンプトのコピー
- レシピJSON貼り付け
- JSONプレビュー
- 項目別バリデーション
- 写真アップロード
- レシピ保存
- レシピ一覧
- 料理名・食材・タグ・気分タグ検索
- レシピ詳細画面
- バージョン履歴表示
- 過去バージョン閲覧
- 既存レシピのGPT相談用プロンプトコピー
- Google Sheets / Drive連携
- エラー表示

## レシピJSON Schema

正式なSchemaは `recipe-schema.json` です。サンプルは `recipe-schema-example.json` を参照してください。

主要項目:

- `schemaVersion`: 現在は `1`
- `recipeId`: 新規レシピは `null`、既存レシピ改良時は元のIDを維持
- `title`: 料理名
- `summary`: 概要
- `servings`: 人数
- `cookingTimeMinutes`: 調理時間
- `ingredients`: 材料と分量
- `steps`: 手順
- `tags`: 料理ジャンル、主食材、用途など
- `moodTags`: 気分タグ
- `memo`: メモ

## ChatGPTで保存用JSONを作る

アプリ内の「GPT用プロンプトをコピー」を押し、ChatGPT Plusへ貼り付けてください。

固定プロンプトは `gpt-save-prompt.txt` にも保存しています。

```text
以下のレシピをOWL Recipeアプリ保存用JSONに変換してください。
説明文、Markdown、コードフェンスは不要です。JSONのみ出力してください。
以下のJSON Schemaに厳密に従ってください。
...
```

ChatGPTからJSONが返ってきたら、アプリの「アプリ保存用JSON」へ貼り付け、「JSONプレビュー」で確認してから保存します。

## 既存レシピをChatGPTで改良する

1. アプリでレシピ詳細を開く
2. 「GPT相談用にコピー」を押す
3. ChatGPT Plusへ貼り付ける
4. 例: 「もう少し酸味を強くしたい」「鶏肉に合うようにしたい」「2人前に変更して」など相談する
5. 最後にChatGPTへ「アプリ保存用JSONのみで出力して」と依頼する
6. 出力されたJSONをアプリへ貼り付けて保存する

この場合、JSON内の `recipeId` は既存レシピのIDを維持します。アプリとGAS側でIDを確認し、同じIDなら新バージョンとして保存します。

## Google Sheetsの準備

1. Google Sheetsで新しいスプレッドシートを作成
2. URLからSpreadsheet IDを控える

シート名 `recipes` はGASが初回実行時に自動作成します。

保存列:

- `recipe_id`
- `version`
- `title`
- `summary`
- `ingredients_text`
- `tags`
- `mood_tags`
- `image_file_id`
- `recipe_json`
- `created_at`

## Google Driveの準備

1. 写真保存用フォルダを作成
2. フォルダURLからDrive Folder IDを控える

写真はこのフォルダへ保存されます。GitHub Pagesから画像表示できるように、アップロードされた画像ファイルは「リンクを知っている全員が閲覧可」に設定されます。

## Google Apps Scriptの準備

1. Apps Scriptプロジェクトを作成
2. `gas/Code.gs` の内容を貼り付ける
3. プロジェクト設定からスクリプトプロパティを追加
   - `SPREADSHEET_ID`: Google SheetsのID
   - `DRIVE_FOLDER_ID`: Google DriveフォルダのID
4. Webアプリとしてデプロイ
   - 実行ユーザー: 自分
   - アクセスできるユーザー: 全員
5. 初回実行時にGoogleの権限許可を行う
6. 発行されたWeb App URLを控える

## フロントエンド設定

`frontend/config.js` を開き、GASのWeb App URLを設定します。

```js
window.APP_CONFIG = {
  GAS_ENDPOINT: "https://script.google.com/macros/s/xxxxxxxxxxxxxxxx/exec"
};
```

## GitHub Pages公開

1. GitHubリポジトリを作成
2. `frontend` 配下のファイルを配置
3. GitHub Pagesを有効化
4. iPhoneのSafariでGitHub Pages URLを開く
5. 共有メニューから「ホーム画面に追加」

## セキュリティ上の注意

このMVPは個人利用・URLを公開しない前提です。

GAS Web Appを「全員」に公開する必要があるため、URLを知っている人はアクセスできる可能性があります。また、写真表示のためDrive上の写真ファイルはリンク閲覧可能になります。

厳密な認証や家族共有などが必要になった場合は、Googleログイン認証、アクセスキー、または別のバックエンド設計を追加してください。本MVPでは新しい外部サービスを追加しません。

## あなたが手動で行う必要がある作業

- Google Sheetsを作成する
- Google Driveの写真保存フォルダを作成する
- Apps Scriptプロジェクトを作成する
- `gas/Code.gs` を貼り付ける
- `SPREADSHEET_ID` と `DRIVE_FOLDER_ID` を設定する
- GAS Web Appをデプロイし、初回権限許可を行う
- GAS Web App URLを `frontend/config.js` に設定する
- GitHub Pagesを有効化する
- iPhoneのSafariで開いてホーム画面に追加する

## こちらで代行しやすい作業

- コード修正
- README整備
- GitHubリポジトリへの反映
- GitHub Pages向けファイル配置
- UI改善
- バリデーション追加
- GASコード作成

Googleの初回認可とGASデプロイ確認は、Googleアカウント権限が必要なため手動操作が必要です。
