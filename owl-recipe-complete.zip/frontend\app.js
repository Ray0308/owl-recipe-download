const $ = (id) => document.getElementById(id);

const RECIPE_SCHEMA_VERSION = 1;

const RECIPE_SCHEMA = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "OWL Recipe JSON",
  "type": "object",
  "additionalProperties": false,
  "required": [
    "schemaVersion",
    "recipeId",
    "title",
    "summary",
    "servings",
    "cookingTimeMinutes",
    "ingredients",
    "steps",
    "tags",
    "moodTags",
    "memo"
  ],
  "properties": {
    "schemaVersion": { "type": "integer", "const": 1 },
    "recipeId": {
      "type": ["string", "null"],
      "description": "新規レシピはnull。既存レシピ改良時は元のrecipeIdを入れる。"
    },
    "title": { "type": "string", "minLength": 1 },
    "summary": { "type": "string" },
    "servings": { "type": ["number", "string"] },
    "cookingTimeMinutes": { "type": ["number", "string"] },
    "ingredients": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "object",
        "additionalProperties": false,
        "required": ["name", "amount"],
        "properties": {
          "name": { "type": "string", "minLength": 1 },
          "amount": { "type": "string" }
        }
      }
    },
    "steps": {
      "type": "array",
      "minItems": 1,
      "items": { "type": "string", "minLength": 1 }
    },
    "tags": {
      "type": "array",
      "items": { "type": "string" }
    },
    "moodTags": {
      "type": "array",
      "items": { "type": "string" }
    },
    "memo": { "type": "string" }
  }
};

const BASE_GPT_PROMPT = `以下のレシピをOWL Recipeアプリ保存用JSONに変換してください。
説明文、Markdown、コードフェンスは不要です。JSONのみ出力してください。
以下のJSON Schemaに厳密に従ってください。

新規レシピの場合、recipeIdはnullにしてください。
既存レシピを改良する場合、指定されたrecipeIdを必ず維持してください。
材料の分量が不明な場合、amountは空文字にしてください。
タグは料理ジャンル、主食材、用途など検索しやすい語にしてください。
気分タグは「さっぱり」「がっつり」「簡単」「温かい」「疲れた日向け」など気分で探しやすい語にしてください。

JSON Schema:
${JSON.stringify(RECIPE_SCHEMA, null, 2)}`;

const recipeJsonEl = $("recipeJson");
const photoEl = $("photo");
const previewEl = $("preview");
const statusEl = $("status");
const recipeListEl = $("recipeList");
const searchInputEl = $("searchInput");
const validationPanelEl = $("validationPanel");
const detailCardEl = $("detailCard");
const detailTitleEl = $("detailTitle");
const detailMetaEl = $("detailMeta");
const detailBodyEl = $("detailBody");
const historyListEl = $("historyList");

let recipes = [];
let currentDetail = null;

$("pasteBtn").addEventListener("click", pasteFromClipboard);
$("previewBtn").addEventListener("click", renderPreview);
$("saveBtn").addEventListener("click", saveRecipe);
$("reloadBtn").addEventListener("click", loadRecipes);
$("copyPromptBtn").addEventListener("click", () => copyText(BASE_GPT_PROMPT, "GPT用プロンプトをコピーしました。"));
$("copyPromptFromDetailBtn").addEventListener("click", () => copyText(BASE_GPT_PROMPT, "GPT用プロンプトをコピーしました。"));
$("copyRecipeBtn").addEventListener("click", copyConsultPrompt);
$("closeDetailBtn").addEventListener("click", () => detailCardEl.classList.add("hidden"));
searchInputEl.addEventListener("input", renderRecipeList);
recipeListEl.addEventListener("click", handleRecipeListClick);
historyListEl.addEventListener("click", handleHistoryClick);

loadRecipes();

async function pasteFromClipboard() {
  try {
    recipeJsonEl.value = await navigator.clipboard.readText();
    renderPreview();
  } catch (error) {
    setStatus("クリップボードを読み取れませんでした。手動で貼り付けてください。", true);
  }
}

function parseRecipe() {
  const raw = recipeJsonEl.value.trim();
  if (!raw) return { ok: false, errors: ["JSONが空です。"], recipe: null };

  let data;
  try {
    data = JSON.parse(raw);
  } catch (error) {
    return { ok: false, errors: [`JSONとして正しくありません: ${error.message}`], recipe: null };
  }

  const normalized = normalizeLegacyRecipe(data);
  const errors = validateRecipe(normalized);

  if (errors.length > 0) return { ok: false, errors, recipe: normalized };
  return { ok: true, errors: [], recipe: normalized };
}

function normalizeLegacyRecipe(data) {
  const recipe = { ...data };
  if (recipe.schema_version && !recipe.schemaVersion) recipe.schemaVersion = recipe.schema_version;
  if (recipe.mood_tags && !recipe.moodTags) recipe.moodTags = recipe.mood_tags;
  if (recipe.cooking_time && !recipe.cookingTimeMinutes) recipe.cookingTimeMinutes = recipe.cooking_time;
  if (recipe.notes && !recipe.memo) recipe.memo = recipe.notes;
  if (!("recipeId" in recipe)) recipe.recipeId = recipe.recipe_id || null;
  if (!("summary" in recipe)) recipe.summary = "";
  return recipe;
}

function validateRecipe(recipe, expectedRecipeId = null) {
  const errors = [];

  if (!recipe || typeof recipe !== "object" || Array.isArray(recipe)) {
    return ["ルートはオブジェクトである必要があります。"];
  }

  requireValue(recipe, "schemaVersion", errors);
  requireValue(recipe, "recipeId", errors, true);
  requireValue(recipe, "title", errors);
  requireValue(recipe, "summary", errors, true);
  requireValue(recipe, "servings", errors);
  requireValue(recipe, "cookingTimeMinutes", errors);
  requireValue(recipe, "ingredients", errors);
  requireValue(recipe, "steps", errors);
  requireValue(recipe, "tags", errors);
  requireValue(recipe, "moodTags", errors);
  requireValue(recipe, "memo", errors, true);

  if (recipe.schemaVersion !== RECIPE_SCHEMA_VERSION) {
    errors.push(`schemaVersionは${RECIPE_SCHEMA_VERSION}である必要があります。`);
  }
  if (recipe.recipeId !== null && typeof recipe.recipeId !== "string") {
    errors.push("recipeIdは文字列またはnullである必要があります。");
  }
  if (typeof recipe.title !== "string" || !recipe.title.trim()) {
    errors.push("titleは空でない文字列である必要があります。");
  }
  if (typeof recipe.summary !== "string") {
    errors.push("summaryは文字列である必要があります。");
  }
  if (!["number", "string"].includes(typeof recipe.servings) || String(recipe.servings).trim() === "") {
    errors.push("servingsは数値または文字列で入力してください。");
  }
  if (!["number", "string"].includes(typeof recipe.cookingTimeMinutes) || String(recipe.cookingTimeMinutes).trim() === "") {
    errors.push("cookingTimeMinutesは数値または文字列で入力してください。");
  }
  if (!Array.isArray(recipe.ingredients) || recipe.ingredients.length === 0) {
    errors.push("ingredientsは1件以上の配列である必要があります。");
  } else {
    recipe.ingredients.forEach((item, index) => {
      if (!item || typeof item !== "object" || Array.isArray(item)) {
        errors.push(`ingredients[${index}]はオブジェクトである必要があります。`);
        return;
      }
      if (typeof item.name !== "string" || !item.name.trim()) {
        errors.push(`ingredients[${index}].nameは空でない文字列である必要があります。`);
      }
      if (typeof item.amount !== "string") {
        errors.push(`ingredients[${index}].amountは文字列である必要があります。`);
      }
    });
  }
  if (!Array.isArray(recipe.steps) || recipe.steps.length === 0) {
    errors.push("stepsは1件以上の配列である必要があります。");
  } else {
    recipe.steps.forEach((step, index) => {
      if (typeof step !== "string" || !step.trim()) {
        errors.push(`steps[${index}]は空でない文字列である必要があります。`);
      }
    });
  }
  validateStringArray(recipe.tags, "tags", errors);
  validateStringArray(recipe.moodTags, "moodTags", errors);
  if (typeof recipe.memo !== "string") errors.push("memoは文字列である必要があります。");
  if (expectedRecipeId && recipe.recipeId !== expectedRecipeId) {
    errors.push(`既存レシピ更新の場合、recipeIdは${expectedRecipeId}である必要があります。`);
  }

  return errors;
}

function requireValue(recipe, key, errors, allowNull = false) {
  if (!(key in recipe) || (!allowNull && recipe[key] === null)) {
    errors.push(`${key}がありません。`);
  }
}

function validateStringArray(value, key, errors) {
  if (!Array.isArray(value)) {
    errors.push(`${key}は配列である必要があります。`);
    return;
  }
  value.forEach((item, index) => {
    if (typeof item !== "string") errors.push(`${key}[${index}]は文字列である必要があります。`);
  });
}

function renderPreview() {
  const result = parseRecipe();
  renderValidation(result.errors);

  if (!result.ok) {
    previewEl.classList.add("hidden");
    setStatus("JSONに修正が必要です。", true);
    return;
  }

  previewEl.classList.remove("hidden");
  previewEl.innerHTML = recipeHtml(result.recipe);
  setStatus("JSONプレビューOK。保存できます。");
}

function renderValidation(errors) {
  if (!errors.length) {
    validationPanelEl.classList.add("hidden");
    validationPanelEl.innerHTML = "";
    return;
  }
  validationPanelEl.classList.remove("hidden");
  validationPanelEl.innerHTML = `<strong>修正が必要です</strong><ul>${errors.map((e) => `<li>${escapeHtml(e)}</li>`).join("")}</ul>`;
}

async function saveRecipe() {
  const endpoint = getEndpoint();
  if (!endpoint) return;

  const parsed = parseRecipe();
  renderValidation(parsed.errors);
  if (!parsed.ok) {
    setStatus("JSONを修正してから保存してください。", true);
    return;
  }

  const expectedRecipeId = parsed.recipe.recipeId || null;
  const recipeErrors = validateRecipe(parsed.recipe, expectedRecipeId);
  if (recipeErrors.length) {
    renderValidation(recipeErrors);
    setStatus("JSONを修正してから保存してください。", true);
    return;
  }

  try {
    setStatus("保存中...");
    const photoBase64 = photoEl.files[0] ? await fileToDataUrl(photoEl.files[0]) : null;
    const body = {
      action: "saveRecipe",
      recipe: parsed.recipe,
      photo: photoBase64 ? {
        dataUrl: photoBase64,
        name: photoEl.files[0].name,
        type: photoEl.files[0].type
      } : null
    };

    const result = await requestJson(endpoint, {
      method: "POST",
      headers: { "Content-Type": "text/plain;charset=utf-8" },
      body: JSON.stringify(body)
    });

    if (!result.ok) throw new Error(result.error || "保存に失敗しました。");

    setStatus(`保存しました: ${result.recipeId} / Ver.${result.version}`);
    recipeJsonEl.value = "";
    photoEl.value = "";
    previewEl.classList.add("hidden");
    validationPanelEl.classList.add("hidden");
    await loadRecipes();
    await openRecipe(result.recipeId);
  } catch (error) {
    setStatus(error.message, true);
  }
}

async function loadRecipes() {
  const endpoint = getEndpoint(false);
  if (!endpoint) {
    setStatus("config.jsにGAS WebアプリURLを設定してください。", true);
    return;
  }

  try {
    const result = await requestJson(`${endpoint}?action=listRecipes`);
    if (!result.ok) throw new Error(result.error || "一覧を取得できませんでした。");
    recipes = result.items || [];
    renderRecipeList();
    if (!recipes.length) setStatus("保存済みレシピはまだありません。");
  } catch (error) {
    setStatus(error.message, true);
  }
}

function renderRecipeList() {
  const queries = searchInputEl.value.trim().toLowerCase().split(/\s+/).filter(Boolean);
  const filtered = recipes.filter((recipe) => {
    if (!queries.length) return true;
    const haystack = [
      recipe.title,
      recipe.summary,
      recipe.ingredientsText,
      recipe.tags,
      recipe.moodTags
    ].join(" ").toLowerCase();
    return queries.every((query) => haystack.includes(query));
  });

  recipeListEl.innerHTML = filtered.length
    ? filtered.map((recipe) => `
      <article class="recipe-item">
        ${recipe.imageUrl ? `<img class="thumb" src="${escapeAttribute(recipe.imageUrl)}" alt="">` : ""}
        <div class="recipe-item-body">
          <h3>${escapeHtml(recipe.title || "")}</h3>
          <p>${escapeHtml(recipe.summary || "")}</p>
          <p>Ver.${escapeHtml(String(recipe.version || ""))} / ${formatDate(recipe.createdAt)}</p>
          <div class="tags">${tagHtml(recipe.tags)}${tagHtml(recipe.moodTags, "mood")}</div>
          <button type="button" data-recipe-id="${escapeAttribute(recipe.recipeId)}">詳細を見る</button>
        </div>
      </article>
    `).join("")
    : `<p class="empty">該当するレシピはありません。</p>`;
}

async function handleRecipeListClick(event) {
  const button = event.target.closest("[data-recipe-id]");
  if (!button) return;
  await openRecipe(button.dataset.recipeId);
}

async function openRecipe(recipeId, version = null) {
  const endpoint = getEndpoint();
  if (!endpoint) return;

  try {
    setStatus("詳細を取得中...");
    const versionParam = version ? `&version=${encodeURIComponent(version)}` : "";
    const result = await requestJson(`${endpoint}?action=getRecipe&recipeId=${encodeURIComponent(recipeId)}${versionParam}`);
    if (!result.ok) throw new Error(result.error || "詳細を取得できませんでした。");
    currentDetail = result.item;
    renderDetail(result.item, result.history || []);
    setStatus("");
  } catch (error) {
    setStatus(error.message, true);
  }
}

function renderDetail(item, history) {
  const recipe = item.recipe;
  detailCardEl.classList.remove("hidden");
  detailTitleEl.textContent = recipe.title;
  detailMetaEl.textContent = `Recipe ID: ${item.recipeId} / Ver.${item.version} / ${formatDate(item.createdAt)}`;
  detailBodyEl.innerHTML = `
    ${item.imageUrl ? `<img class="hero-photo" src="${escapeAttribute(item.imageUrl)}" alt="${escapeAttribute(recipe.title)}">` : ""}
    ${recipeHtml(recipe)}
  `;
  historyListEl.innerHTML = history.length
    ? history.map((entry) => `
      <button class="history-item ${entry.version === item.version ? "active" : ""}" type="button" data-history-id="${escapeAttribute(entry.recipeId)}" data-version="${escapeAttribute(entry.version)}">
        <span>Ver.${escapeHtml(entry.version)}</span>
        <small>${formatDate(entry.createdAt)}</small>
      </button>
    `).join("")
    : `<p class="empty">履歴はありません。</p>`;
  detailCardEl.scrollIntoView({ behavior: "smooth", block: "start" });
}

async function handleHistoryClick(event) {
  const button = event.target.closest("[data-history-id]");
  if (!button) return;
  await openRecipe(button.dataset.historyId, button.dataset.version);
}

function recipeHtml(recipe) {
  return `
    <div class="recipe-render">
      <p>${escapeHtml(recipe.summary || "")}</p>
      <div class="fact-grid">
        <div><span>人数</span><strong>${escapeHtml(recipe.servings)}</strong></div>
        <div><span>調理時間</span><strong>${escapeHtml(recipe.cookingTimeMinutes)}分</strong></div>
      </div>
      <h3>材料</h3>
      <ul>${recipe.ingredients.map((item) => `<li><strong>${escapeHtml(item.name)}</strong> ${escapeHtml(item.amount)}</li>`).join("")}</ul>
      <h3>手順</h3>
      <ol>${recipe.steps.map((step) => `<li>${escapeHtml(step)}</li>`).join("")}</ol>
      <div class="tags">${tagHtml(recipe.tags)}${tagHtml(recipe.moodTags, "mood")}</div>
      ${recipe.memo ? `<p><strong>メモ:</strong> ${escapeHtml(recipe.memo)}</p>` : ""}
    </div>
  `;
}

function copyConsultPrompt() {
  if (!currentDetail) {
    setStatus("先にレシピ詳細を開いてください。", true);
    return;
  }
  const prompt = `以下はOWL Recipeアプリに保存済みのレシピです。
このレシピについて相談・改良したいです。

現在のrecipeId: ${currentDetail.recipeId}
現在のバージョン: ${currentDetail.version}

変更後は必ずOWL Recipeアプリ保存用JSONのみで出力してください。
説明文、Markdown、コードフェンスは不要です。
recipeIdは必ず「${currentDetail.recipeId}」のまま維持してください。
schemaVersionは${RECIPE_SCHEMA_VERSION}にしてください。

現在のレシピJSON:
${JSON.stringify(currentDetail.recipe, null, 2)}

JSON Schema:
${JSON.stringify(RECIPE_SCHEMA, null, 2)}`;

  copyText(prompt, "GPT相談用プロンプトをコピーしました。");
}

async function copyText(text, message) {
  try {
    await navigator.clipboard.writeText(text);
    setStatus(message);
  } catch (error) {
    setStatus("クリップボードへコピーできませんでした。", true);
  }
}

function getEndpoint(showError = true) {
  const endpoint = window.APP_CONFIG?.GAS_ENDPOINT;
  if (!endpoint || endpoint.includes("PASTE_YOUR")) {
    if (showError) setStatus("config.jsにGAS WebアプリURLを設定してください。", true);
    return "";
  }
  return endpoint;
}

async function requestJson(url, options) {
  const response = await fetch(url, options);
  const text = await response.text();
  try {
    return JSON.parse(text);
  } catch (error) {
    throw new Error(`サーバー応答をJSONとして読めませんでした。HTTP ${response.status}`);
  }
}

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error("写真を読み込めませんでした。"));
    reader.readAsDataURL(file);
  });
}

function tagHtml(value, type = "") {
  return String(value || "")
    .split(",")
    .map((tag) => tag.trim())
    .filter(Boolean)
    .map((tag) => `<span class="tag ${type}">${escapeHtml(tag)}</span>`)
    .join("");
}

function formatDate(value) {
  if (!value) return "";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return String(value);
  return date.toLocaleString("ja-JP", { month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" });
}

function setStatus(message, isError = false) {
  statusEl.textContent = message;
  statusEl.classList.toggle("error", Boolean(isError));
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function escapeAttribute(value) {
  return escapeHtml(value).replaceAll("`", "&#096;");
}
