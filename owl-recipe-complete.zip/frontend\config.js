// Google Apps Script Web App URLを設定してください。
window.APP_CONFIG = {
  GAS_ENDPOINT: "PASTE_YOUR_GAS_WEB_APP_URL_HERE"
};
