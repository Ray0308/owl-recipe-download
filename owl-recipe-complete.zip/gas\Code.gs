const SHEET_NAME = "recipes";
const SCHEMA_VERSION = 1;

// Script Properties:
// SPREADSHEET_ID: Google Sheets ID
// DRIVE_FOLDER_ID: Google Drive folder ID for recipe photos

function doGet(e) {
  try {
    const action = (e.parameter.action || "").trim();

    if (action === "listRecipes") {
      return jsonResponse({ ok: true, items: listLatestRecipes() });
    }

    if (action === "getRecipe") {
      const recipeId = e.parameter.recipeId || "";
      const version = e.parameter.version ? Number(e.parameter.version) : null;
      return jsonResponse(getRecipe(recipeId, version));
    }

    return jsonResponse({ ok: false, error: "Unknown action." });
  } catch (err) {
    return jsonResponse({ ok: false, error: String(err.message || err) });
  }
}

function doPost(e) {
  try {
    const payload = JSON.parse((e.postData && e.postData.contents) || "{}");

    if (payload.action === "saveRecipe") {
      const result = saveRecipe(payload.recipe, payload.photo);
      return jsonResponse(Object.assign({ ok: true }, result));
    }

    return jsonResponse({ ok: false, error: "Unknown action." });
  } catch (err) {
    return jsonResponse({ ok: false, error: String(err.message || err) });
  }
}

function saveRecipe(recipe, photo) {
  validateRecipe(recipe);

  const sheet = getSheet();
  ensureHeader(sheet);

  const records = readRecords(sheet);
  const suppliedRecipeId = recipe.recipeId || "";
  let recipeId = suppliedRecipeId;
  let maxVersion = 0;
  let previousImageFileId = "";

  if (suppliedRecipeId) {
    const existing = records.filter(function (record) {
      return record.recipeId === suppliedRecipeId;
    });
    if (existing.length === 0) {
      throw new Error("指定されたrecipeIdの既存レシピが見つかりません: " + suppliedRecipeId);
    }
    existing.forEach(function (record) {
      maxVersion = Math.max(maxVersion, Number(record.version) || 0);
      if (record.version === maxVersion && record.imageFileId) {
        previousImageFileId = record.imageFileId;
      }
    });
  } else {
    recipeId = Utilities.getUuid();
    recipe.recipeId = recipeId;
  }

  const version = maxVersion + 1;
  let imageFileId = previousImageFileId;

  if (photo && photo.dataUrl) {
    imageFileId = savePhoto(photo, recipeId, version);
  }

  const ingredientsText = recipe.ingredients
    .map(function (item) {
      return String((item.name || "") + " " + (item.amount || "")).trim();
    })
    .join(" / ");

  sheet.appendRow([
    recipeId,
    version,
    recipe.title,
    recipe.summary || "",
    ingredientsText,
    (recipe.tags || []).join(","),
    (recipe.moodTags || []).join(","),
    imageFileId,
    JSON.stringify(recipe),
    new Date()
  ]);

  return {
    recipeId: recipeId,
    version: version,
    imageFileId: imageFileId,
    imageUrl: imageUrl(imageFileId)
  };
}

function listLatestRecipes() {
  const sheet = getSheet();
  ensureHeader(sheet);

  const records = readRecords(sheet);
  const latestById = {};

  records.forEach(function (record) {
    if (!latestById[record.recipeId] || latestById[record.recipeId].version < record.version) {
      latestById[record.recipeId] = record;
    }
  });

  return Object.keys(latestById)
    .map(function (key) {
      return publicRecord(latestById[key], false);
    })
    .sort(function (a, b) {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
}

function getRecipe(recipeId, version) {
  if (!recipeId) throw new Error("recipeId is required.");

  const sheet = getSheet();
  ensureHeader(sheet);

  const records = readRecords(sheet).filter(function (record) {
    return record.recipeId === recipeId;
  });
  if (records.length === 0) {
    return { ok: false, error: "レシピが見つかりません。" };
  }

  records.sort(function (a, b) {
    return a.version - b.version;
  });

  let selected = null;
  if (version) {
    selected = records.find(function (record) {
      return record.version === version;
    });
    if (!selected) return { ok: false, error: "指定されたバージョンが見つかりません。" };
  } else {
    selected = records[records.length - 1];
  }

  return {
    ok: true,
    item: publicRecord(selected, true),
    history: records.map(function (record) {
      return {
        recipeId: record.recipeId,
        version: record.version,
        title: record.title,
        createdAt: record.createdAt
      };
    }).reverse()
  };
}

function readRecords(sheet) {
  const values = sheet.getDataRange().getValues();
  if (values.length <= 1) return [];

  const header = values[0].map(function (value) {
    return String(value);
  });
  const index = {};
  header.forEach(function (name, i) {
    index[name] = i;
  });

  return values.slice(1).filter(function (row) {
    return row[index.recipe_id] !== "";
  }).map(function (row) {
    const recipeJson = String(row[index.recipe_json] || "{}");
    let recipe = {};
    try {
      recipe = JSON.parse(recipeJson);
    } catch (err) {
      recipe = {};
    }

    const record = {
      recipeId: String(row[index.recipe_id] || ""),
      version: Number(row[index.version] || 0),
      title: String(row[index.title] || ""),
      summary: index.summary == null ? String(recipe.summary || "") : String(row[index.summary] || ""),
      ingredientsText: String(row[index.ingredients_text] || ""),
      tags: String(row[index.tags] || ""),
      moodTags: String(row[index.mood_tags] || ""),
      imageFileId: String(row[index.image_file_id] || ""),
      recipeJson: recipeJson,
      recipe: normalizeRecipe(recipe),
      createdAt: row[index.created_at]
    };

    if (!record.recipe.recipeId) record.recipe.recipeId = record.recipeId;
    return record;
  });
}

function publicRecord(record, includeRecipe) {
  const result = {
    recipeId: record.recipeId,
    version: record.version,
    title: record.title,
    summary: record.summary,
    ingredientsText: record.ingredientsText,
    tags: record.tags,
    moodTags: record.moodTags,
    imageFileId: record.imageFileId,
    imageUrl: imageUrl(record.imageFileId),
    createdAt: record.createdAt
  };
  if (includeRecipe) result.recipe = record.recipe;
  return result;
}

function savePhoto(photo, recipeId, version) {
  const folderId = PropertiesService.getScriptProperties().getProperty("DRIVE_FOLDER_ID");
  if (!folderId) throw new Error("DRIVE_FOLDER_IDが未設定です。");

  const match = String(photo.dataUrl || "").match(/^data:(.+);base64,(.+)$/);
  if (!match) throw new Error("写真データの形式が不正です。");

  const mimeType = match[1];
  if (!/^image\//.test(mimeType)) throw new Error("写真ファイルのみアップロードできます。");

  const bytes = Utilities.base64Decode(match[2]);
  const maxBytes = 7 * 1024 * 1024;
  if (bytes.length > maxBytes) {
    throw new Error("写真が大きすぎます。7MB以下にしてください。");
  }

  const extension = extensionFromMime(mimeType);
  const safeName = String(photo.name || "photo").replace(/[\\/:*?"<>|]/g, "_");
  const name = recipeId + "_v" + version + "_" + safeName.replace(/\.[^.]+$/, "") + "." + extension;
  const blob = Utilities.newBlob(bytes, mimeType, name);
  const file = DriveApp.getFolderById(folderId).createFile(blob);

  // GitHub Pagesから表示できるよう、リンクを知っている人が閲覧可能にします。
  file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  return file.getId();
}

function validateRecipe(recipe) {
  const errors = [];

  if (!recipe || typeof recipe !== "object" || Array.isArray(recipe)) {
    throw new Error("recipeはオブジェクトである必要があります。");
  }

  if (recipe.schemaVersion !== SCHEMA_VERSION) errors.push("schemaVersionは" + SCHEMA_VERSION + "である必要があります。");
  if (!("recipeId" in recipe)) errors.push("recipeIdがありません。");
  if (recipe.recipeId !== null && recipe.recipeId !== "" && typeof recipe.recipeId !== "string") errors.push("recipeIdは文字列またはnullである必要があります。");
  if (typeof recipe.title !== "string" || !recipe.title.trim()) errors.push("titleは空でない文字列である必要があります。");
  if (typeof recipe.summary !== "string") errors.push("summaryは文字列である必要があります。");
  if (!["number", "string"].includes(typeof recipe.servings) || String(recipe.servings).trim() === "") errors.push("servingsは数値または文字列である必要があります。");
  if (!["number", "string"].includes(typeof recipe.cookingTimeMinutes) || String(recipe.cookingTimeMinutes).trim() === "") errors.push("cookingTimeMinutesは数値または文字列である必要があります。");
  if (!Array.isArray(recipe.ingredients) || recipe.ingredients.length === 0) errors.push("ingredientsは1件以上の配列である必要があります。");
  if (!Array.isArray(recipe.steps) || recipe.steps.length === 0) errors.push("stepsは1件以上の配列である必要があります。");
  if (!Array.isArray(recipe.tags)) errors.push("tagsは配列である必要があります。");
  if (!Array.isArray(recipe.moodTags)) errors.push("moodTagsは配列である必要があります。");
  if (typeof recipe.memo !== "string") errors.push("memoは文字列である必要があります。");

  if (Array.isArray(recipe.ingredients)) {
    recipe.ingredients.forEach(function (item, index) {
      if (!item || typeof item !== "object" || Array.isArray(item)) errors.push("ingredients[" + index + "]はオブジェクトである必要があります。");
      else {
        if (typeof item.name !== "string" || !item.name.trim()) errors.push("ingredients[" + index + "].nameは空でない文字列である必要があります。");
        if (typeof item.amount !== "string") errors.push("ingredients[" + index + "].amountは文字列である必要があります。");
      }
    });
  }

  if (Array.isArray(recipe.steps)) {
    recipe.steps.forEach(function (step, index) {
      if (typeof step !== "string" || !step.trim()) errors.push("steps[" + index + "]は空でない文字列である必要があります。");
    });
  }

  if (errors.length) throw new Error(errors.join(" / "));
}

function normalizeRecipe(recipe) {
  if (!recipe || typeof recipe !== "object") return recipe;

  if (recipe.schema_version && !recipe.schemaVersion) recipe.schemaVersion = recipe.schema_version;
  if (recipe.mood_tags && !recipe.moodTags) recipe.moodTags = recipe.mood_tags;
  if (recipe.cooking_time && !recipe.cookingTimeMinutes) recipe.cookingTimeMinutes = recipe.cooking_time;
  if (recipe.notes && !recipe.memo) recipe.memo = recipe.notes;
  if (!("recipeId" in recipe)) recipe.recipeId = recipe.recipe_id || null;
  if (!("summary" in recipe)) recipe.summary = "";

  recipe.schemaVersion = recipe.schemaVersion || SCHEMA_VERSION;
  recipe.ingredients = Array.isArray(recipe.ingredients) ? recipe.ingredients : [];
  recipe.steps = Array.isArray(recipe.steps) ? recipe.steps : [];
  recipe.tags = Array.isArray(recipe.tags) ? recipe.tags : [];
  recipe.moodTags = Array.isArray(recipe.moodTags) ? recipe.moodTags : [];
  recipe.memo = recipe.memo || "";
  return recipe;
}

function getSheet() {
  const spreadsheetId = PropertiesService.getScriptProperties().getProperty("SPREADSHEET_ID");
  if (!spreadsheetId) throw new Error("SPREADSHEET_IDが未設定です。");

  const spreadsheet = SpreadsheetApp.openById(spreadsheetId);
  let sheet = spreadsheet.getSheetByName(SHEET_NAME);
  if (!sheet) sheet = spreadsheet.insertSheet(SHEET_NAME);
  return sheet;
}

function ensureHeader(sheet) {
  const expected = [
    "recipe_id",
    "version",
    "title",
    "summary",
    "ingredients_text",
    "tags",
    "mood_tags",
    "image_file_id",
    "recipe_json",
    "created_at"
  ];

  if (sheet.getLastRow() === 0) {
    sheet.appendRow(expected);
    return;
  }

  const current = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(function (value) {
    return String(value);
  });

  if (current.indexOf("summary") === -1) {
    sheet.insertColumnAfter(3);
    sheet.getRange(1, 4).setValue("summary");
  }
}

function imageUrl(fileId) {
  if (!fileId) return "";
  return "https://drive.google.com/uc?export=view&id=" + encodeURIComponent(fileId);
}

function extensionFromMime(mimeType) {
  const map = {
    "image/jpeg": "jpg",
    "image/png": "png",
    "image/webp": "webp",
    "image/heic": "heic",
    "image/heif": "heif"
  };
  return map[mimeType] || "bin";
}

function jsonResponse(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
